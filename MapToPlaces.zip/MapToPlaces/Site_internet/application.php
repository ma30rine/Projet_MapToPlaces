<!DOCTYPE html>
<html>
	
	<head>
 
		<title>MapToPlaces : Application</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
		<link rel="shortcut icon" href="image/petit_logo.png" />
		<link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

		<?php 
	
			//Conection à la base de donnée
			$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	
			//ouverture de la session
			session_start();
		?>

		<!--CSS intégré-->
		<style>

			.main{
			
				width: 1000px;
				padding: 15px;
				margin-top: 10px;
				margin-bottom: 10px;
				height: 504px;
				border-width: 3px;
				border-color: grey;
				border-style: double;
				background-color: white;
				margin-left: auto;
				margin-right: auto;
				border-radius:8px;
				text-align: center;
			}

		</style>
	</head>

	<body>

		<!--Menu horizontal-->
		<div class="bandeau_top">

			<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>

			<ul id="menu_horizontal">

				<?php

					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
					}
					
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo '<li><a href="connexion.php">Connexion</a></li>';
					}
				?>

				<li><a href="presentation.php">Présentation</a></li>
				<li><a href="application.php">Application</a></li>
			</ul>

			<div class="session">

				<?php
					
					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
					}
					
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo "Vous n'êtes pas connecté";
					}
				?>
			
			</div>
		</div>
 
		<!--Présentation du projet-->
		<div class='main'>
		
			<div id="map">
		
				</br></br>
				<h2><font class="nom">MapToPlaces</font> est bientôt disponible sur Google Play</h2>				
				<p><font class="nom">MapToPlaces</font> est une application par les montpellierain, pour les montpellierain qui regroupe un ensemble de services disponibles 
				dans la ville de Montpellier.</p>
				<p class="sans_marge">Que vous recherchiez un restaurant, un arrêt de taxis, des 
				toilettes publiques, un club de sport ou un hôtel ; cette application est faites 
				pour vous ! Ces services ont été répartis en 5 catégories :</p>
				</br>
   		
				<ul>
   			
					<li>Hébergement</li>
					<li>Loisir</li>
					<li>Magasin</li>
					<li>Nourriture</li>
					<li>Utilitaires</li>
				</ul>
		
				</br>
				<p>Que vous soyez montpellierain biensur ou simple visiteur, vous pourrez trouvez tout ce 
				que vous désirez et même plus ! De plus, vous pourrez vous rendre très facilement 
				sur les lieux qui vous aurez choisis.</p>
				<br><br>
				<p class="centre"><strong>Pour pouvoir utiliser pleinement les fonctions de l'application, 
				n'hésitez pas à vous <a href="inscription.php">inscrire</a> !</strong></p>
				<p>Une fois inscrit, vous aurez la possibilité de laisser un avis sur les 
				différents lieux que vous aurez visité. Vous pourrez également consulter les avis 
				des autres utilisateurs.</p>
			</div>
				
			<div class="bouton">
		
				<img src="image/accueil.png" alt= "Page d'Accueil" height=500/>
			</div>
 
		</div>
	</body>
</html> 