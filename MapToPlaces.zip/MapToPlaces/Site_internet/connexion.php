<!DOCTYPE html>
<html>
	
	<head>
 
		<title>MapToPlaces : Connexion</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
		<link rel="shortcut icon" href="image/petit_logo.png" />
		<link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

		<?php 
	
			//Connection à la base de donnée
			$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	
			//Ouverture de la session
			session_start();
		?>

		<!--script de la carte-->
		<script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
		<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />

		<!--<script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
		<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />-->
 
	</head>

	<body>

		<!--Menu horizontal-->
		<div class="bandeau_top">

			<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>

			<ul id="menu_horizontal">

				<?php

					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
					}
	
					//S'affiche si l'utilisateur n'est pas connecté
					else{
						
						echo '<li><a href="connexion.php">Connexion</a></li>';
					}
				?>

				<li><a href="presentation.php">Présentation</a></li>
				<li><a href="application.php">Application</a></li>
			</ul>

			<div class="session">

				<?php
	
					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
					}
	
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo "Vous n'êtes pas connecté";
					}
				?>
			
			</div>
		</div>
 
		<div class='main'>
	
			<!--CARTE-->
			<div id = 'map'></div>
	
				<script>
		
					//clé d'accès
					mapboxgl.accessToken = 'pk.eyJ1IjoibWFwdG9wbGFjZXMiLCJhIjoiY2oxMjU5cXVtMDA0cTMzcndxOWRjNjcxbCJ9.2eD1QePtF98GS3fFjG4HMQ';
		
					//création de la carte
					var map = new mapboxgl.Map({
			
						container: 'map', // container id
						style: 'mapbox://styles/mapbox/streets-v9', //stylesheet location
						center: [<?php echo $_SESSION['longitude'].",".$_SESSION['latitude']; ?>], // starting position
						zoom: 12 // starting zoom
					});	
		
					//boutons de contrôle de la carte
					map.addControl(new mapboxgl.GeolocateControl());
					map.addControl(new mapboxgl.NavigationControl());
 
				</script>
 
				<div class='bouton'>
	
					</br></br></br></br></br></br></br>
					<h2>Connectez-vous :</h2>
					</br>
	
					<!--formulaire de connection-->
					<form method='POST' action='connecter.php' autocomplete=off>
	
						Adresse e-mail : <br/><INPUT type="text" name="mail" value="<?php echo $_GET['mail'] ?>"><br/><br/>
						Mot de passe : <br/><INPUT type="password" name="mdp" value="<?php echo $_GET['mdp1'] ?>"><br/><br/>
		
						<input type="submit" value="Envoyer">
					</form>
				
					</br>
					Montpellierain(e) sans compte ? Inscrivez vous : <a href='inscription.php'>ici</a> !
				</div>
			
			</div>
		
		</div>
	
	</body>
 
</html> 