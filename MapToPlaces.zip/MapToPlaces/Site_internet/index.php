<!DOCTYPE html>
<html>
	
	<head>

		<title>MapToPlaces</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
		<link rel="shortcut icon" href="image/petit_logo.png" />
		<link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

		<?php 
	
			//Connection à la base de donnée
			$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
			
			session_start();
	
			//Fixe la position par défaut de l'utilisateur 
			if(isset($_GET['lat'])){
		
				$_SESSION['latitude']=$_GET['lat'];
			}
	
			elseif(!isset($_SESSION['latitude'])){
		
				$_SESSION['latitude']=43.60907140;
			}
	
			if(isset($_GET['lon'])){
		
				$_SESSION['longitude']=$_GET['lon'];
			}
	
			elseif(!isset($_SESSION['longitude'])){
		
				$_SESSION['longitude']=3.8800466;
			}

		?>

		<!--script de la carte-->
		<script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
		<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />
 
	</head>

	<body>

		<!--Menu horizontal-->
		<div class="bandeau_top">

			<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>

			<ul id="menu_horizontal">

				<?php

					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
					}
	
					//S'affiche si l'utilisateur n'est pas connecté
					else{
						
						echo '<li><a href="connexion.php">Connexion</a></li>';
					}
				?>

				<li><a href="presentation.php">Présentation</a></li>
				<li><a href="application.php">Application</a></li>
			</ul>

			<div class="session">

				<?php
	
					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
					}
					
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo "Vous n'êtes pas connecté";
					}
				?>

			</div>
		</div>
 
		<div class='main'>
		
			<!--CARTE-->
			<div id='map'></div>
				
				<script>
					
					//clé d'accès
					mapboxgl.accessToken = 'pk.eyJ1IjoibWFwdG9wbGFjZXMiLCJhIjoiY2oxMjU5cXVtMDA0cTMzcndxOWRjNjcxbCJ9.2eD1QePtF98GS3fFjG4HMQ';

					//Affichage des icônes "lieu" de la carte
					var geojson = {
						"id": "places",
						"type": "symbol",
						"source": {
							"type": "geojson",
							"data": {
								"type": "FeatureCollection",
								"features": [
								
									<?php 
									
										//Récupération de la catégorie
										if(isset($_GET['categorie'])){
										
											$categorie = $_GET['categorie'];
										}
			
										//Catégorie par défaut
										else{
			
											$categorie = 'all';
										}
									
										//Récupération du nombre de lieu a afficher
										if(isset($_GET['nombreresult'])){
			
											$nombreresult = $_GET['nombreresult'];
										}
			
										//Nombre de lieu a afficher par défaut
										else{
			
											$nombreresult = 10;
										}
										
										//Execution de la fonction plus près qui renvoie les lieux les plus proches de l'utilisateur
										$result = plus_pres( $_SESSION[latitude], $_SESSION[longitude], $categorie, $nombreresult);
	
										//Pour chaque résultat de la requête
										foreach ($result as $key => $val) {
		
											//Requête SQL qui recupère les informations du lieu
											$repo = $bdd->query("SELECT * FROM lieu WHERE osm_id='".$key."';");
											
											//Affichage de l'icône du lieu à la position du lieu
											while($rep = $repo ->fetch()){
			
												echo '{'."\n";
												echo '	"type": "'.$rep['categorie'].'",'."\n";
												echo '	"ident": "'.$rep['osm_id'].'",'."\n";
												echo '	"properties": {'."\n";
												echo '		"description": "<p><a href='."'lieu.php?id=".$rep['osm_id']."' target=\'_blank\' title=\'Opens in a new window\'>".$rep['nom'].'</a></p>",'."\n";
												echo '		"message": "'.$rep['nom'].'",'."\n";
												echo '		"iconSize": [32, 32]'."\n";
												echo '	},'."\n";
												echo '	"geometry": {'."\n";
												echo '		"type": "Point",'."\n";
												echo '		"coordinates": ['."\n";
												echo '			'.$rep['X'].","."\n";
												echo '			'.$rep['Y']."\n";
												echo '		]'."\n";
												echo '	}'."\n";
												echo '},'."\n";
											}
										}
									
										//Affichage de l'icône de l'utilisateur à la position de l'utilisateur
										echo '{'."\n";
										echo '	"type": "position",'."\n";
										echo '	"ident": "0",'."\n";
										echo '	"properties": {'."\n";
										echo '		"description": "<p><a href='."'lieu.php?id=".$rep['osm_id']."' target=\'_blank\' title=\'Opens in a new window\'>".$rep['nom'].'</a></p>",'."\n";
										echo '		"message": "Votre position",'."\n";
										echo '		"iconSize": [32, 32]'."\n";
										echo '	},'."\n";
										echo '	"geometry": {'."\n";
										echo '		"type": "Point",'."\n";
										echo '		"coordinates": ['."\n";
										echo '			'.$_SESSION[longitude].","."\n";
										echo '			'.$_SESSION[latitude]."\n";
										echo '		]'."\n";
										echo '	}'."\n";
										echo '},'."\n";
									?>
		
								]
							}
						}
					};

					//Création de la carte, paramètrage de la carte
					var map = new mapboxgl.Map({
		
						container: 'map', // container id
						style: 'mapbox://styles/mapbox/streets-v9', //stylesheet location
						center: [<?php echo $_SESSION['longitude'].",".$_SESSION['latitude']; ?>], // starting position
						zoom: 17 // starting zoom
					});
	
					geojson.source.data.features.forEach(function(marker) {
		
						// create a DOM element for the marker
						var el = document.createElement('div');
						el.className = 'marker';
						el.style.backgroundImage = 'url(image/'+marker.type+'_bis.png)';
						el.style.width = marker.properties.iconSize[0] + 'px';
						el.style.height = marker.properties.iconSize[1] + 'px';
						el.title = marker.properties.message;
		
						if(marker.ident!=0){
			
							el.addEventListener('click', function() {
							
								window.document.location.href='lieu.php?id='+marker.ident;
							});
						}

						// add marker to map
			
						new mapboxgl.Marker(el, {offset: [-marker.properties.iconSize[0] / 2, -marker.properties.iconSize[1] / 2]})
						.setLngLat(marker.geometry.coordinates)
						.addTo(map);
					});
		
					//boutons de contrôle de la carte
					map.addControl(new mapboxgl.GeolocateControl());
					map.addControl(new mapboxgl.NavigationControl());

				</script>
 
				<!--BOUTONS-->
				<div class='bouton'>
		
					<!--Chaque boutons est associé à un catégorie, cliquer sur le boutons renvoie vers la page index avec la catégorie associé en paramètre-->
					<div class='bouton_gauche'>
		
						<a href='index.php?categorie=all'><img src= "image/reset.png"><h3>Sans filtre</h3></a>
						<a href='index.php?categorie=Nourriture'><img src= "image/Nourriture.png" class="image_cat"><h3>Nourriture</h3></a>
						<a href='index.php?categorie=Loisirs'><img src= "image/Loisirs.png" class="image_cat"><h3>Loisirs</h3></a>
					</div>
		
					<div class='bouton_droit'>
						
						<a href='index.php?categorie=Hébergement'><img src= "image/Hébergement.png" class="image_cat"><h3>Hébergement</h3></a>
						<a href='index.php?categorie=Utilitaires'><img src= "image/Utilitaires.png" class="image_cat"><h3>Utilitaires</h3></a>
						<a href='index.php?categorie=Magasin'><img src= "image/Magasin.png" class="image_cat"><h3>Commerces</h3></a>
					</div>
				</div>
			</div>
 
 
			<?php
	
				//Permat à l'utilisateur d'afficher plus de lieux
				echo "<div class='plusresultat'><a href='index.php?categorie=".$categorie."&nombreresult=".((int)$nombreresult+5)."'>Afficher 5 résultats de plus</a></div>";
	
				//Execution de la fonction plus près qui renvoie les lieux les plus proches de l'utilisateur
				$result = plus_pres( $_SESSION[latitude], $_SESSION[longitude], $categorie, $nombreresult);
	
				//Pour chaque résultat 
				foreach ($result as $key => $val) {
	
					//Requête SQL qui récupère les informations du lieu
					$repo = $bdd->query("SELECT * FROM lieu WHERE osm_id='".$key."';");
	
					//Affiche les informations relative au lieu disponible dans la base de donnée
					while ($rep = $repo ->fetch()){
		
						echo "<div class='lieu'>";
						echo "<div class='image_lieu'>";
						echo '<a href="lieu.php?id='.$rep['osm_id'].'"><img src= "image/'.$rep['categorie'].'.png" class="image_cat"></a>';
						echo "</div>";
						echo "<div class='text_lieu'>";
		
						echo 'Nom: '.$rep['nom'].' </br>';
		
						if(isset($_SESSION['mail'])){
			
							echo 'Distance estimée: '.round($result[$rep['osm_id']]*1000).'m </br>';
						}
						
						echo 'Type: '.$rep['type'].' </br>';
		
						if($rep['telephone'] != NULL){
		
							echo 'Téléphone: '.$rep['telephone'].' </br>';
						}
		
						if($rep['acces_pmr'] != NULL){
		
							echo 'Accès personne à mobilité réduite : '.$rep['acces_pmr'].' </br>';
						}
		
						if($rep['site_web'] != NULL){
		
							echo 'Site web: <a href="http:'.'//'.$rep['site_web'].'" target="_blank">'.$rep['site_web'].'</a> </br>';
						}
		
						if($rep['operateur'] != NULL){
		
							echo 'Opérateur: '.$rep['operateur'].' </br>';
						}
		
						if($rep['marque'] != NULL){
		
							echo 'Marque: '.$rep['marque'].' </br>';
						}
		
						if($rep['sport'] != NULL){
		
							echo 'Sport: '.$rep['sport'].' </br>';
						}
		
						if($rep['source'] != NULL){
		
							echo 'Source: '.$rep['source'].' </br>';
						}
		
						if($rep['referent'] != NULL){
		
							echo 'Référent: '.$rep['referent'].' </br>';
						}
		
						if($rep['date_mhs'] != NULL){
		
							echo 'Date classement monument historique: '.$rep['date_mhs'].' </br>';
						}
		
						if($rep['payant'] != NULL){
		
							echo 'Payant: '.$rep['payant'].' </br>';
						}
		
						if($rep['abris'] != NULL){
		
							echo 'Abris: '.$rep['abris'].' </br>';
						}
		
						if($rep['banc'] != NULL){
		
							echo 'Banc: '.$rep['banc'].' </br>';
						}
					}
	
					echo "</div></div><div class='nul'></div>\n";
					
				}

				//Fonction qui execute une requête SQL qui renvoie les lieux les plus proches d'une position
				function plus_pres( $posy, $posx, $cat, $taille=5){
	
					//connection à la base de donnée
					$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	
					// Requête sans catégorie
					if($cat=='all'){
						
						$rep = $bdd->query("SELECT X, Y, categorie, osm_id, nom FROM lieu;");
					}
					//Requête avec catégorie
					else{
						
						$rep = $bdd->query("SELECT X, Y, categorie, osm_id, nom FROM lieu WHERE categorie='".$cat."';");
					}
					
					// On crée le tableau
					$tab = array();
	
					// Boucle
					while($donnees = $rep -> fetch()){
	
						// On calcule la distance entre le lieu et l'utilisateur
						$distx = 111.132*($posx-$donnees['X']); //111.132 valeur de conversion de la latitude en mètre.
						$disty = 111.320*($posy-$donnees['Y']); //111.320 valeur de conversion de la longitude en mètre.
						$dis = sqrt(($distx)**2 + ($disty)**2);
	
						// On rempli le tableau
						$tab[$donnees['osm_id']] = $dis;
	
					}
	
					//Classement du tableau par distance croissante
					asort($tab);
					
					//Réglage de la taille du tableau
					$result = array_slice($tab, 0, $taille);
					
					return $result;
				}

			?>
		<!--</div>-->
	</body>
</html> 