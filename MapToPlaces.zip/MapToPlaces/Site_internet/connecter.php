<!DOCTYPE html>
<html>
	
	<head>
 
		<title>MapToPlaces : Connexion</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
		<link rel="shortcut icon" href="image/petit_logo.png" />
		<link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

		<?php 

			//Connection à la base de donnée
			$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');

			//Requête SQL, récupère les information de l'utilisateur qui se "connecte"
			$requet = "select * from utilisateur where email='".$_POST["mail"]."' AND mot_de_passe='".$_POST["mdp"]."'";
			
			//Execute la requête
			$rep = $bdd->query($requet);
			
			//Lecture du résultat de la requête
			$identifiant = $rep->fetch();

			//S'affiche si l'utilisateur n'a pas remplis les champs 
			if($_POST['mail']=="" || $_POST['mdp']==""){
	
				echo '<meta http-equiv="refresh" content="1; URL=connexion.php?mail='.$_POST['mail'].'">';
			}

			//S'affiche si l'utilisateur a correctement remplis les champs
			elseif($identifiant[email]!=NULL){
	
				//Ouverture de la session
				session_start();
	
				//Initialisation des variables de session
				$_SESSION['nom']= $identifiant[nom];
				$_SESSION['prenom']= $identifiant[prenom];
				$_SESSION['mail']=$identifiant[email];
	
				echo '<meta http-equiv="refresh" content="1; URL=index.php">';
			}

			//S'affiche si les donnée saisies n'existe pas dans la base de donnée
			else{
	
				echo '<meta http-equiv="refresh" content="1; URL=connexion.php?mail='.$_POST['mail'].'">';
			}
		?>

		<!--CARTE-->
		<script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
		<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />

		<!--Géolocalisation-->
		<script>

			//Si réussite de géolocalisation
			function geo_success(position) {
				
				document.location.href="index.php?lat="+position.coords.latitude+"&lon="+position.coords.longitude;
			}

			//Si échec de géolocalisation
			function geo_error() {
 
				alert("Sorry, no position available.");
			}

			//Paramètre
			var geo_options = {
  
				enableHighAccuracy: true, 
				maximumAge        : 30000, 
				timeout           : 27000
			};

			//Si le navigateur autorise la géolocalisation
			if ("geolocation" in navigator) {
  
				//Execution de la fonction de géolocalisation : 3 paramètre (réussite, échec, paramètre)
				navigator.geolocation.getCurrentPosition(geo_success, geo_error, geo_options);
			} 
			else {
				
				/* geolocation IS NOT available */
			}
		</script>
	
	</head>

	<body>

		<!--Menu horizontal-->
		<div class="bandeau_top">

			<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>

			<ul id="menu_horizontal">

				<?php

					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
					}
	
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo '<li><a href="connexion.php">Connexion</a></li>';
					}
				?>

				<li><a href="presentation.php">Présentation</a></li>
				<li><a href="application.php">Application</a></li>
			</ul>

			<div class="session">

				<?php
	
					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
					}
	
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo "Vous n'êtes pas connecté";
					}
				?>

			</div>
		</div>

		<div class='plusresultat'>

			<?php

				//Si champs vides
				if($_POST['mail']=="" || $_POST['mdp']==""){
	
					echo "Un des champs est manquant, vous allez être redirigé vers la page de connexion.";
				}

				//Si champs correctes
				elseif($identifiant[email]!=NULL){
	
					echo "Bonjour ".$_SESSION['prenom'];
					echo ", bienvenue, nous vous souhaitons une bonne visite ! Nous vous redirigeons vers l'acceuil.";
					echo "</BR>";
				}

				//Si champs incorrectes
				else{
	
					echo "Désolé, votre email et votre mot de passe ne correspondent pas.";
				}
			?>
		</div>
	</body>
</html>