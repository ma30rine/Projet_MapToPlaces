
<!DOCTYPE html>
<html>
	
	<head>
 
		<title>MapToPlaces : Deconnexion</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

		<link rel="shortcut icon" href="image/petit_logo.png" />
		<link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

		<?php
  
			//Ouverture de la session
			session_start();
  
			//Destruction de la session
			session_destroy();
 
			//redirection vers index.php
			echo '<meta http-equiv="refresh" content="0; URL=index.php">';
		?>
	</head>

	<body>
		
		<!--Menu horizontal-->
		<div class="bandeau_top">

			<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>

			<ul id="menu_horizontal">

				<li><a href="connexion.php">Connexion</a></li>
				<li><a href="presentation.php">Présentation</a></li>
				<li><a href="application.php">Application</a></li>
			</ul>
			
			<!--Information de session-->
			<div class="session">

				<?php

					echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
				?>
			</div>
		
		</div>
	</body>
</html>