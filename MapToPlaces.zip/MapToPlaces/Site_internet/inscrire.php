<!DOCTYPE html>
<html>

	<head>

		<title>MapToPlaces : Nouveau</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
		<link rel="shortcut icon" href="../image/logo.gif" />
		<link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

		<?php 

			$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');
			
			//Permet de remplir la base de données "client" avec les informations données en paramètre
			function enregistrer($nom, $prenom, $numero, $mail, $mdp){
		
				//connection à la base de donnée
				$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');
		
				//requête SQL de type "INSERT"
				$requet =  "INSERT INTO `utilisateur`(`email`, `nom`, `prenom`, `telephone`, `mot_de_passe`) VALUES ('".$mail."','".$nom."','".$prenom."','".$numero."','".$mdp."')";
				//execution de la requête
				$bdd->exec($requet);
			}
	
			//Permet de vérifier dans la base de donnée si il n'existe pas d'adresse mail identique 
			function verif($mail){
	
				//connection à la base de donnée
				$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');
	
				//requête SQL
				$ver = "SELECT COUNT(`email`) as 'bol' FROM `utilisateur` WHERE `email`='".$mail."'";
				
				//execution de la requête
				$bool = $bdd->query($ver);
				
				//lecture du premier résultat
				$lol = $bool->fetch();
				
				//Si le résultat de la requête n'est pas vide
				if($lol['bol']!=0){
		
					//la fonction renvoie et affiche FALSE
					return FALSE;
					echo "FALSE";
				}
				
				//sinon
				else{
		
					//la fonction renvoie et affiche TRUE
					return TRUE;
					echo "TRUE";
				}
			}

			$double = FALSE;

			//Verifie si tout les champs ont été "rempli" par l'utilisateur
			if($_POST['mail']=="" || $_POST['mail2']=="" || $_POST['mdp']=="" || $_POST['mdp2']=="" || $_POST['lastname']=="" || $_POST['firstname']=="" || $_POST['tel']==""){
	
				echo '<meta http-equiv="refresh" content="1; URL=inscription.php?mail='.$_POST['mail'].'&lastname='.$_POST['lastname'].'&firstname='.$_POST['firstname'].'&tel='.$_POST['tel'].'">';
			}

			//Verifie si les deux saisie de l'adresse mail et du mot de passe sont identique, verifie si l'adresse mail saisie "ressemble" a une adresse mail. Verifie si le numéro de téléphone "ressemble" à un numéro de téléphone.
			elseif(($_POST['mdp'] !== $_POST['mdp2']) || ($_POST['mail'] !== $_POST['mail2']) || (!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) || (!preg_match('`[0-9]{10}`',$_POST['tel']))){
	
				echo '<meta http-equiv="refresh" content="1; URL=inscription.php?mail='.$_POST['mail'].'&lastname='.$_POST['lastname'].'&firstname='.$_POST['firstname'].'&tel='.$_POST['tel'].'">';
			}

			//Verifie que l'adresse mail saisie est unique
			elseif(!verif($_POST['mail'])){
	
				echo '<meta http-equiv="refresh" content="1; URL=inscription.php?lastname='.$_POST['lastname'].'&firstname='.$_POST['firstname'].'&tel='.$_POST['tel'].'">';
				$double = TRUE;
			}

			//Si toutes les verifications sont OK, execute la fonction enregistrer.
			else{
	
				enregistrer($_POST['lastname'], $_POST['firstname'], $_POST['tel'], $_POST['mail'], $_POST['mdp']);
			}
		?>
	</head>

	<body>
	
		<!--Menu horizontal-->
		<div class="bandeau_top">

			<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>

			<ul id="menu_horizontal">

				<?php

					//S'affiche si l'utilsateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
					}
	
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo '<li><a href="connexion.php">Connexion</a></li>';
					}
				?>

				<li><a href="presentation.php">Présentation</a></li>
				<li><a href="application.php">Application</a></li>

			</ul>

			<div class="session">

				<?php
	
					//S'affiche si l'utilisateur est connecté
					if($_SESSION[mail]!==NULL){
		
						echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
					}
	
					//S'affiche si l'utilisateur n'est pas connecté
					else{
		
						echo "Vous n'êtes pas connecté";
					}
				?>
			
			</div>
		</div>

		<div class='center'>

			<?php

				//S'affiche si un champ n'a pas été rempli
				if($_POST['mail']=="" || $_POST['mail2']=="" || $_POST['mdp']=="" || $_POST['mdp2']=="" || $_POST['lastname']=="" || $_POST['firstname']=="" || $_POST['tel']==""){
	
					echo "Un des champs est manquant, vous allez être redirigé vers la page d'inscription.";
				}

				//S'affiche si le numéro de téléphone n'est pas "valide"
				if(!preg_match('`[0-9]{10}`',$_POST['tel'])){	
	
					echo "Le numéro de téléphone n'est pas valide.";
				}

				//S'affiche si les mots de passe saisies sont différents
				elseif($_POST['mdp'] !== $_POST['mdp2']){
	
					echo "Les mots de passes ne sont pas similaires, vous allez être redirigé vers la page d'inscription.";
				}

				//S'affiche si l'adresse mail saisie n'est pas "valide"
				elseif(!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) {
   
				echo "Votre email n'est pas valide.";
				}

				//S'affiche si les adresse mail saisies sont différentes
				elseif($_POST['mail'] !== $_POST['mail2']){
	
					echo "Les adresses emails ne sont pas similaires, vous allez être redirigé vers la page d'inscription.";	
				}

				//S'affiche si l'adresse mail n'est pas unique
				elseif($double){
	
					echo 'Un compte existe déjà avec cette adresse email.';
				}

				//S'affiche si tout est OK
				else{
	
					echo "</BR> Bonjour ".$_POST['firstname'];
					echo ", bienvenue, nous vous souhaitons une bonne visite ! Vous pouvez maintenant vous connecter.</BR>";
					echo "</BR><h2>Connectez-vous :</h2></BR>";

					//Permet de connecter automtiquement l'utilisateur
					echo "<form method='POST' action='connecter.php' autocomplete=off>";
					echo "Adresse e-mail :<INPUT type='text' name='mail' value=".$_GET['mail']."><br/><br/>";
					echo "Mot de passe : <INPUT type='password' name='mdp' value=".$_GET['mdp1']."><br/><br/>";
					echo "<input type='submit' value='Envoyer'>";
					echo "</form>";
					
					echo "</BR>";
					echo "<a href='index.php?categorie=all'><img src='image/logo_fond_blanc.png' height=258px></a>";
					echo "</BR>";
				}
			?>
		
		</div>

	</body>
</html>
